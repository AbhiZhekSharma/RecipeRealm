package com.reciperealm;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class AddRecipeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String ingredients = request.getParameter("ingredients");
        String steps = request.getParameter("steps");
        int userId = (int) request.getSession().getAttribute("userId");

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO recipes (title, ingredients, steps, user_id) VALUES (?, ?, ?, ?)");
            stmt.setString(1, title);
            stmt.setString(2, ingredients);
            stmt.setString(3, steps);
            stmt.setInt(4, userId);
            stmt.executeUpdate();
            response.sendRedirect("index.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("addRecipe.jsp?error=1");
        }
    }
}