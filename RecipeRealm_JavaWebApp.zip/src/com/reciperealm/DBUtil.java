package com.reciperealm;

import java.sql.*;

public class DBUtil {
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/reciperealm", "root", "password");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}